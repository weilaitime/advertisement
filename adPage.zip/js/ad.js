var API_URL;
if (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") {
    API_URL = "https://localhost:44307/";
} else {
    API_URL = "https://imagefeapi.azurewebsites.net/";
}


let num = 1;
document.getElementById('file-upload').onchange = function (event) {
    var file = event.target.files[0];
    var reader = new FileReader();

    reader.onload = function (e) {
        var previewImage = document.getElementById('preview-image');
        previewImage.src = e.target.result;
        previewImage.style.display = 'block'; // 显示预览图  
        document.getElementById('btn-image').disabled = false; // 启用分析图片按钮  
    };

    reader.readAsDataURL(file); // 读取文件内容
};

document.getElementById('add-card').addEventListener('mouseover', function (event) {
    event.target.style.fontWeight = "bold";
});
document.getElementById('add-card').addEventListener('mouseleave', function (event) {
    event.target.style.fontWeight = "normal";
});

// 这个函数会被绑定到重置按钮的点击事件上  
function resetfunction() {
    // 选取所有的按钮  
    const buttons = document.querySelectorAll('.btn-secondary');

    // 遍历按钮，移除active类  
    buttons.forEach(button => {
        button.classList.remove('active');
    });

    const textareas = document.querySelectorAll('textarea');

    // 遍历所有选取的元素，并清空它们的内容  
    textareas.forEach(textarea => {
        textarea.value = '';
    });
    var previewImage = document.getElementById('preview-image');
    previewImage.src = "";
    previewImage.style.display = 'none'; // 显示预览图
}

function validate() {
    // 获取已选择的平台、语言、品类
    var selectedPlatform = $('.btn-group[aria-label="First group"] .btn.active').text();
    var selectedLanguage = $('.btn-group[aria-label="Second group"] .btn.active').text();
    var selectedCategory = $('.btn-group[aria-label="Third group"] .btn.active').text();
    // 如果平台没有被选择，显示一个警告并停止处理
    if (!selectedPlatform) {
        alert('请先选择平台！');
        return false;
    }
    // 如果语言没有被选择，显示一个警告并停止处理  
    if (!selectedLanguage) {
        alert('请先选择语言！');
        return false;
    }
    // 如果品类没有被选择，显示一个警告并停止处理  
    if (!selectedCategory) {
        alert('请先选择一个品类！');
        return false;
    }

    return true;
}

$(document).ready(function () {   //这个页面全部加载完之后就去执行写入的js
    $('#add-card').click(function () {
        //克隆模板
        var newCard = $('#competition-0').clone();
        //移除ID并显示新表单
        newCard.removeAttr('id').show();
        var title = newCard.find('h5.card-title');
        title.text('竞品' + (++num));
        //添加到competition容器
        $('.competition-container').append(newCard);
    });
    // 绑定删除事件到新表单的删除按钮  
    $('.competition-container').on('click', '.delete-card', function () {
        // 移除最近的.card元素，即整个竞品信息表单
        var result = confirm("是否删除竞品信息？");
        if (result) {
            $(this).closest('.card').remove();
            num--;
        }
    });

    // 当按钮被点击时  
    $('.btn-group .btn').click(function () {
        var divObject = $(this).closest('div.btn-group');
        if ($(this).hasClass('active')) {
            $(this).removeClass('active')
            if($(this).text() === '其他') {
                if(divObject.attr('aria-label') === 'Second group'){
                    $('#otherLanguage').css('display', 'none');
                }else{
                    $('#otherCategory').css('display', 'none');
                }
            }
        } else {
            // 首先移除当前按钮组中所有按钮的active类  
            $(this).siblings().removeClass('active');
            // 给当前点击的按钮添加active类  
            $(this).addClass('active');

            if($(this).text() === '其他') {
                if(divObject.attr('aria-label') === 'Second group'){
                    $('#otherLanguage').css('display', 'block');
                }else{
                    $('#otherCategory').css('display', 'block');
                }
            }else{
                if(divObject.attr('aria-label') === 'Second group'){
                    $('#otherLanguage').css('display', 'none');
                }else{
                    $('#otherCategory').css('display', 'none');
                }
            }
        }
    });

    // 绑定点击事件到重置按钮  
    document.querySelector('#reset-button').addEventListener('click', resetfunction);
});

var rotateText = ['提交.', '提交..', '提交...'];
var btnName = 'btn-submit';
var btnName2 = 'btn-image';
var originalText = document.getElementById(btnName).innerHTML;
var originalText2 = document.getElementById(btnName2).innerHTML;
$(document).ready(function () {

    $('.competition-container').on('click', 'input[value="获取数据"]', function () {
        var selectedPlatform = $('.p-btn:first .btn.active').text();
        if (selectedPlatform !== '亚马逊') {
            alert('该功能目前仅支持亚马逊平台');
            return;
        }
        var currentDiv = $(this).closest('div.card');
        var url = $(this).closest('.input-group').find('.input-group-text').text() + $(this).siblings("input[name='url']").val();
        // 正则表达式来验证 URL  
        var urlRegEx = new RegExp('^(https?:\\/\\/)?' + // protocol  
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name and extension  
            '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address  
            '(\\:\\d+)?' + // port  
            '(\\/[-a-z\\d%_.~+]*)*' + // path  
            '(\\?[;&amp;a-z\\d%_.~+=-]*)?' + // query string  
            '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator  
        if (!urlRegEx.test(url)) {
            alert("请输入有效的 URL");
            return false;
        }

        const requestURL = 'Crawler?url=' + url;

        $.ajax({
            url: requestURL,
            type: 'GET',
            timeout: 2000000,
            xhrFields: {
                withCredentials: true
            },
            success: function (response) {
                console.log(response);
                if (typeof response === 'string' && response.startsWith('Error:')) {
                    console.error('An error occurred: ' + response);
                } else {
                    var ans = JSON.parse(response).data[0];
                    if (ans && ans.title && ans.description && ans.feature) {
                        var title = ans.title.replace(/['"\\]/g, '');
                        var description = ans.description.join('\n').replace(/['"\\]/g, ''); // join array into string with newline separator
                        var feature = '';
                        for (var key in ans.feature) { // loop through feature object
                            feature += key + ': ' + ans.feature[key] + '\n'; // append key and value to feature string
                        }
                        feature = feature.replace(/['"\\]/g, '');

                        // 模拟数据
                        var mockData = {
                            title: '模拟产品标题',
                            parameters: '模拟产品参数',
                            content: '模拟竞品文案'
                        }

                        // 填充数据到对应的地方
                        currentDiv.find('textarea[name="com-title"]').val(title);
                        currentDiv.find('textarea[name="com-para"]').val(feature);
                        currentDiv.find('textarea[name="com-content"]').val(description);
                    } else {
                        console.error('ans or ans properties are undefined');
                    }
                }
            },

            error: function (e) {
                console.log('请求失败');
            }
        })

    });

    $('#btn-image').click(function (e) {
        e.preventDefault();
        if (!validate()) return;

        var imageData = $('#preview-image').attr('src');
        var selectedLanguage = $('.btn-group[aria-label="Second group"] .btn.active').text();
        var selectedCategory = $('.btn-group[aria-label="Third group"] .btn.active').text();
        var requestData = { Language: selectedLanguage, Category: selectedCategory, Image: imageData };

        document.querySelectorAll('button').forEach(button => {
            button.disabled = true;
        });
        var i = 0;
        var timer = setInterval(function () {
            document.getElementById(btnName2).innerHTML = rotateText[i];
            i = (i + 1) % rotateText.length;
        }, 500);

        $.ajax({
            url: API_URL + 'api/Advertise/GetImageInfo',
            type: 'POST',
            data: JSON.stringify(requestData),
            contentType: "application/json;charset=utf-8",
            dataType: 'json',
            timeout: 2000000,
            success: function (response) {
                console.log(response);
                var imageInfo = response.description;
                $('#txtImageInsight').css('display', 'block');
                $('#txtImageInsight [name="pro-para"]').val(imageInfo);
            },
            error: function (xhr, status, error) {
                console.error('请求失败：' + error);
            },
            complete: function (xhr, status) {
                console.log('完成');
                clearInterval(timer);
                document.querySelectorAll('button').forEach(button => {
                    button.disabled = false;
                });
                document.getElementById(btnName2).innerHTML = originalText2;
            }
        });
    });

    $('#btn-submit').click(function (e) {
        e.preventDefault();
        if (!validate()) return;

        // 获取已选择的平台、语言、品类
        var selectedPlatform = $('.btn-group[aria-label="First group"] .btn.active').text();
        var selectedLanguage = $('.btn-group[aria-label="Second group"] .btn.active').text();
        if(selectedLanguage === '其他'){
            selectedLanguage = $('#otherLanguage').val();
            alert(selectedLanguage)
        } 
        var selectedCategory = $('.btn-group[aria-label="Third group"] .btn.active').text();
        if(selectedCategory === '其他'){
            selectedCategory = $('#otherCategory').val()
            alert(selectedCategory)
        }
        var selectedCompetitorCategory = $('.btn-group[aria-label="Fouth group"] .btn.active').text();
        // 获取竞品信息
        var competitors = [];

        document.querySelectorAll('button').forEach(button => {
            button.disabled = true;
        });
        var i = 0;
        var timer = setInterval(function () {
            document.getElementById(btnName).innerHTML = rotateText[i];
            i = (i + 1) % rotateText.length;
        }, 500);

        $('.competition-container .card').each(function () {
            if (!$(this).is(':hidden')) {
                var title = $(this).find('[name="com-title"]').val();
                var feature = $(this).find('[name="com-para"]').val();
                var description = $(this).find('[name="com-content"]').val();
                competitors.push({
                    Title: title,
                    Feature: feature,
                    Description: description
                });
            }
        });

        // 获取用户产品参数
        var userProductFeature = $('[name="pro-para"]').val();

        // 获取图片文件
        var imageFile = $('#file-upload')[0].files[0];
        //var imageData = $('#preview-image').attr('src');
        var imageData = $('#txtImageInsight [name="pro-para"]').val();
        //var formData = new FormData();
        //formData.append('Image', imageFile);

        // 构建请求数据对象
        var requestData = {
            Feature: userProductFeature,
            Competitor: competitors,
            Language: selectedLanguage,
            Platform: selectedPlatform,
            Category: selectedCategory,
            CompetitorCategory: selectedCompetitorCategory,
            Image: imageData
        };

        // 将JSON对象添加到formData
        //formData.append('data', JSON.stringify(requestData));

        console.log(requestData);

        // 发送AJAX请求
        $.ajax({
            //url: 'https://localhost:44307/api/Advertise',  // 替换为实际的API URL
            url: API_URL + 'api/Advertise',  // 替换为实际的API URL
            type: 'POST',
            data: JSON.stringify(requestData),
            contentType: "application/json;charset=utf-8",
            dataType: 'json',
            timeout: 2000000,
            success: function (response) {
                // 处理返回的数据
                console.log(response);
                var title = response.title;
                var description = response.description;
                var kwd = response.keyword;
                // 在这里更新UI或者其他逻辑
                console.log('产品标题：' + title);
                console.log('产品文案：' + description);
                console.log('产品关键字：' + kwd);
                //将id为advertisement的div变成可见，并将产品标题、产品文案、产品关键字填入
                $('#advertisement').css('display', 'block');
                $('#advertisement [name="com-title"]').val(title);
                $('#advertisement [name="com-para"]').val(kwd);
                $('#advertisement [name="com-content"]').val(description);

            },
            error: function (xhr, status, error) {
                // 处理错误
                alert('请求失败+' + error);
                console.error('请求失败：' + error);
            },
            complete: function (xhr, status) {
                console.log('完成');
                clearInterval(timer);
                document.querySelectorAll('button').forEach(button => {
                    button.disabled = false;
                });
                document.getElementById(btnName).innerHTML = originalText;
            }
        });
    })
})